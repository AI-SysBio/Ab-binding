# Test cases
python3.6 abligity.py --mode 0 --pdb_dir example --pip_dir example -v
python3.6 abligity.py --mode 0 --pdb_dir example_model --pip_dir example_model --seqs example_model/alphasynucleinS1.csv --affinity_label kD\(nM\) -v
