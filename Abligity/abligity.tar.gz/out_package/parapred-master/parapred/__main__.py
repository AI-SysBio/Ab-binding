from .parapred import main
main()
