#!/usr/bin/env python
from parapred.dev_runner import main

if __name__=="__main__":
    main()
