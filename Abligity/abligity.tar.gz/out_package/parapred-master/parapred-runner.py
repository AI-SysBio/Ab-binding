#!/usr/bin/env python
from parapred.parapred import main

if __name__=="__main__":
    main()
